
declare module'*.css';
declare module '*.jsx';
declare module 'papaparse';
declare module '*.js';
declare module '*ts';