function Message(){
    // this type of code is called JavaScript XML 
    // allows to mix hml code with js code
    return <h1> Hello world</h1>;
}

export default Message;